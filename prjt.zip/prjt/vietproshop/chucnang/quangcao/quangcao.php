<div id="banner-l">
	<h2 class="h2-bar">đối tác</h2>
	<a href="#">
		<img class="img-thumbnail" src="images/banner01.png">
	</a>
</div>